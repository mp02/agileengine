package main

import (
	"bytes"
	"fmt"
	"io/ioutil"

	"golang.org/x/net/html"
)

func main() {

	data, err := ioutil.ReadFile("sample-0-origin.html")
	if err != nil {
		panic(err)
	}
	//fmt.Println(string(data))
	// xmlFile, err := os.Open("sample-0-origin.html")

	reader := bytes.NewReader(data)
	doc, err := html.Parse(reader)
	if err != nil {
		// ...
	}
	var f func(*html.Node)
	f = func(n *html.Node) {
		if n.Type == html.ElementNode && n.Data == "a" {
			// Do something with n...
			fmt.Println("Attr", n.Attr)
			fmt.Println("Data", n.Data)
			fmt.Println("DataAtom", n.DataAtom)
			fmt.Println("FirstChild", n.FirstChild)
			fmt.Println("LastChild", n.LastChild)
			fmt.Println("Namespace", n.Namespace)
			fmt.Println("NextSibling", n.NextSibling)
			fmt.Println("Parent", n.Parent)
			fmt.Println("PrevSibling", n.PrevSibling)
			fmt.Println("Type", n.Type)
		}
		for c := n.FirstChild; c != nil; c = c.NextSibling {
			f(c)
		}
	}
	f(doc)
	// z := html.NewTokenizer(reader)

	// for {
	// 	tt := z.Next()

	// 	switch {
	// 	case tt == html.ErrorToken:
	// 		// End of the document, we're done
	// 		return
	// 	case tt == html.StartTagToken:
	// 		t := z.Token()

	// 		isAnchor := t.Data == "a"
	// 		if isAnchor {
	// 			fmt.Println("We found a link!", t)
	// 		}
	// 	}
	// }
}
